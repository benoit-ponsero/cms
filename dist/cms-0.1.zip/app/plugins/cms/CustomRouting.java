package plugins.cms;

import play.Logger;
import play.PlayPlugin;
import play.mvc.Http.Request;
import play.mvc.Http.Response;

/**
 * @author benoit
 */
public class CustomRouting extends PlayPlugin {

    @Override
    public boolean rawInvocation(Request request, Response response) throws Exception {
        
        //List<Domain> domain = Domain.findAll();
        
        
        Logger.info("efefezfzeqq");
        
        return false;
    }
}
