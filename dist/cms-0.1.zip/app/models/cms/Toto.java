package models.cms;

import javax.persistence.Entity;
import play.db.jpa.Model;

/**
 * @author benoit
 */
@Entity
public class Toto extends Model{
    
    public int qq;
}
